#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export TRAIN_SEED=605
exec bash launch.sh
